from socket import *
from threading import *
import time
from datetime import datetime

serverPort = 1235
serverSocket = socket(AF_INET,SOCK_STREAM) # Creating the socket and binding it to the port
serverSocket.bind(('',serverPort))
serverSocket.listen(1)
print('server ready')
def handle_client(clientSocket):
    while True:
        received = clientSocket.recv(4096) # receiving from client
        if not received:
            clientSocket.close() # Closing the socket if nothing is received from the client
            break
        else:
            curr_time = datetime.now()
            to_send = str(curr_time.time()).encode('utf-8')
            print(to_send)
            clientSocket.sendall(to_send) # Sending the current time to the client

while True:
        connectionSocket, address = serverSocket.accept()
        Thread(target=handle_client,args=(connectionSocket,)).start() # Applying the multi-threading mechanism to process multiple client requests sent at the same time 